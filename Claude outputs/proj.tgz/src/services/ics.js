'use strict';
const { createEvents } = require('ics');
const db = require('../db');
const { sessionPublicLabel } = require('./email');
const { doubleBookingMapForSession, sessionsForPlayer } = require('./sessionHelper');
const personalEvents = require('./personalEvents');

// Sorts events chronologically by their [y, mo, d, hh, mm] start (Kyle,
// 2026-09-26: "make sure all dates are sorted by date") — league matches and
// My Other Dates entries are gathered separately, so without this they'd be
// grouped by source in the file rather than interleaved in date order.
function sortByStart(events) {
  return events.sort((a, b) => {
    for (let i = 0; i < 5; i++) {
      const d = (a.start[i] || 0) - (b.start[i] || 0);
      if (d) return d;
    }
    return 0;
  });
}

const DEFAULT_DURATION_MINUTES = 90; // not specified in the spec; adjust here if match length differs

function buildPlayerICS(playerId, sessionId) {
  const session = db.prepare('SELECT * FROM sessions WHERE id = ?').get(sessionId);
  const player = db.prepare('SELECT * FROM players WHERE id = ?').get(playerId);
  if (!session || !player) return { error: 'Session or player not found' };

  const rows = db
    .prepare(
      `SELECT w.match_date, wa.status, wa.is_sub
       FROM week_assignments wa JOIN weeks w ON w.id = wa.week_id
       WHERE wa.player_id = ? AND w.session_id = ? AND wa.status != 'subbed_out'
       ORDER BY w.match_date`
    )
    .all(playerId, sessionId);

  const [hh, mm] = session.match_time.split(':').map(Number);
  if (![hh, mm].every(Number.isFinite)) {
    return { error: `Session has an invalid match_time (${JSON.stringify(session.match_time)}) — can't build a calendar file.` };
  }

  // Same double-booking detection used everywhere else a player sees their
  // own schedule (see sessionHelper.js's doubleBookingMapForSession) — a
  // downloaded/subscribed calendar invite is exactly the kind of "weeks in
  // advance" surface Kyle asked for, so a conflict shouldn't only show up on
  // the website.
  const dbMap = doubleBookingMapForSession(sessionId);

  const events = rows.map((r) => {
    const [y, mo, d] = r.match_date.split('-').map(Number);
    if (![y, mo, d].every(Number.isFinite)) {
      // Legacy/bad row — skip it rather than feeding NaN into the ics
      // library, which would silently produce a broken .ics file (or throw
      // deep inside a third-party dependency) instead of a clear error.
      return null;
    }
    const doubleBooked = dbMap.get(`${playerId}|${r.match_date}`);
    return {
      title: `${doubleBooked ? 'DOUBLE BOOKED — ' : ''}Doubles${r.is_sub ? ' (sub)' : ''} — ${sessionPublicLabel(session)}`,
      start: [y, mo, d, hh, mm],
      duration: { minutes: DEFAULT_DURATION_MINUTES },
      description: `Doubles match for ${player.name}. Full schedule: ${(process.env.PUBLIC_SITE_URL || '')}/schedule`
        + (doubleBooked ? ` WARNING: you're also scheduled to play in ${sessionPublicLabel(doubleBooked)} on this same date — sort this out before match day.` : ''),
      status: 'CONFIRMED',
    };
  }).filter(Boolean);

  // Player-entered "other dates" (Kyle, 2026-09-26) that falls inside this
  // session's date range, so the one-time download is one calendar with
  // everything for that stretch — see personalEvents.js.
  for (const ev of personalEvents.eventsInRange(playerId, session.start_date, session.end_date)) {
    const e = personalEvents.toIcsEvent(ev);
    if (e) events.push(e);
  }

  const { error, value } = createEvents(sortByStart(events));
  if (error) return { error: error.message || String(error) };
  return { value };
}

/**
 * Builds a *subscribable* feed (as opposed to buildPlayerICS's one-time
 * download): every scheduled/active, non-archived session this player is
 * currently enrolled in, not just one. A calendar app re-fetches this same
 * URL periodically (interval is the app's own choice — X-PUBLISHED-TTL below
 * is only a hint, and some clients, notably Google Calendar, ignore it and
 * poll on their own schedule, often much less than hourly), so unlike a
 * downloaded file it stays in sync automatically as re-scheduling happens —
 * no re-download needed after every "Schedule these players" run.
 *
 * The stable, deterministic `uid` per event is the part that makes
 * "subscribe" actually work correctly rather than just "re-download
 * repeatedly": the `ics` library defaults to a random uid per build when one
 * isn't supplied, which would make every single refresh look like a calendar
 * full of brand-new events to the subscribing app instead of updates to the
 * same ones — Apple/Google Calendar would accumulate duplicates forever
 * instead of updating in place. Built from session id + match date + player
 * id, so the same real-world match always maps to the same UID across every
 * fetch, and (RFC 5545's own recommendation) suffixed with a domain-like tag
 * for global uniqueness.
 */
function buildPlayerFeedICS(playerId) {
  const player = db.prepare('SELECT * FROM players WHERE id = ?').get(playerId);
  if (!player) return { error: 'Player not found' };

  // sessionHelper.js's sessionsForPlayer() — covers both roster enrollment
  // *and* any session where this player currently holds a real upcoming
  // assignment without ever being on that session's own roster (a sub —
  // see that function's doc comment). Without this, a confirmed sub's own
  // match never showed up on their calendar subscription, same bug as My
  // Page (Kyle, 2026-09-07). Archived sessions are still meant to go fully
  // quiet and a draft session still has no schedule yet — sessionsForPlayer()
  // applies those same filters.
  const sessions = sessionsForPlayer(playerId);

  const events = [];
  for (const session of sessions) {
    const [hh, mm] = session.match_time.split(':').map(Number);
    if (![hh, mm].every(Number.isFinite)) continue; // bad row on this one session — skip it, don't break the whole feed

    const rows = db
      .prepare(
        `SELECT w.match_date, wa.status, wa.is_sub
         FROM week_assignments wa JOIN weeks w ON w.id = wa.week_id
         WHERE wa.player_id = ? AND w.session_id = ? AND wa.status != 'subbed_out'
         ORDER BY w.match_date`
      )
      .all(playerId, session.id);

    // Same double-booking detection as buildPlayerICS above — see that
    // function's comment. Computed once per session, not per event.
    const dbMap = doubleBookingMapForSession(session.id);

    for (const r of rows) {
      const [y, mo, d] = r.match_date.split('-').map(Number);
      if (![y, mo, d].every(Number.isFinite)) continue;
      const doubleBooked = dbMap.get(`${playerId}|${r.match_date}`);
      events.push({
        uid: `assignment-${session.id}-${r.match_date}-${playerId}@tennis-scheduler.local`,
        title: `${doubleBooked ? 'DOUBLE BOOKED — ' : ''}Doubles${r.is_sub ? ' (sub)' : ''} — ${sessionPublicLabel(session)}`,
        start: [y, mo, d, hh, mm],
        duration: { minutes: DEFAULT_DURATION_MINUTES },
        // Key omitted entirely (not set to undefined) when there's no court
        // info — safer than relying on the ics library treating an explicit
        // `undefined` value the same as an absent key.
        ...(session.court_info ? { location: session.court_info } : {}),
        description: `Doubles match for ${player.name}. Full schedule: ${(process.env.PUBLIC_SITE_URL || '')}/schedule?session=${session.id}`
          + (doubleBooked ? ` WARNING: you're also scheduled to play in ${sessionPublicLabel(doubleBooked)} on this same date — sort this out before match day.` : ''),
        status: 'CONFIRMED',
      });
    }
  }

  // Player-entered "other dates" (Kyle, 2026-09-26) — every row, so the
  // subscribed calendar holds all of this player's tennis. Stable
  // personal-<id> uids let a deleted/edited entry update in place.
  for (const ev of personalEvents.allEvents(playerId)) {
    const e = personalEvents.toIcsEvent(ev);
    if (e) events.push(e);
  }

  const { error, value } = createEvents(sortByStart(events), { calName: `Doubles — ${player.name}` });
  if (error) return { error: error.message || String(error) };
  return { value };
}

module.exports = { buildPlayerICS, buildPlayerFeedICS };
