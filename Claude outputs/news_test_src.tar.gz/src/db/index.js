// Uses Node's built-in node:sqlite (available Node >=22.5, no native compile step —
// deliberately chosen over better-sqlite3 so `npm install` has zero native build
// dependencies, which matters most on a Raspberry Pi.
const path = require('path');
const fs = require('fs');
const { DatabaseSync } = require('node:sqlite');

const DB_PATH = process.env.SQLITE_PATH || path.join(__dirname, '..', '..', 'data', 'tennis.db');

fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const raw = new DatabaseSync(DB_PATH);
raw.exec('PRAGMA journal_mode = WAL');
raw.exec('PRAGMA foreign_keys = ON');

const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
raw.exec(schema);

// Lightweight migration guard: schema.sql's CREATE TABLE IF NOT EXISTS won't
// add new columns to a table that already exists from an earlier version of
// this app. There's no full migration system here (small single-admin app),
// so instead we just check for columns added after initial release and add
// them in place if missing, preserving existing data.
function ensureColumn(table, column, definition) {
  const cols = raw.prepare(`PRAGMA table_info(${table})`).all();
  if (!cols.some((c) => c.name === column)) {
    raw.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition}`);
    return true; // column was just added
  }
  return false; // already existed
}
function hasColumn(table, column) {
  return raw.prepare(`PRAGMA table_info(${table})`).all().some((c) => c.name === column);
}
ensureColumn('email_log', 'status', "TEXT NOT NULL DEFAULT 'sent'");
// body_html (Kyle, 2026-09-27): the exact HTML body sent, so the Email Log
// page can pop up "what did this person actually get". Bare nullable column —
// every older row simply has no stored body (nothing to backfill from).
ensureColumn('email_log', 'body_html', 'TEXT');
// thread_key (Kyle, 2026-09-27): groups one event's emails (a whole sub
// request's trail) on the Email Log page. Bare nullable column — older rows
// stay ungrouped on purpose rather than guessing which request they belong to.
ensureColumn('email_log', 'thread_key', 'TEXT');
raw.exec('CREATE INDEX IF NOT EXISTS idx_email_log_thread_key ON email_log(thread_key)');
// Multi-court support: every existing row predates courts, so they're all
// implicitly court 1 — exactly what the default backfills.
ensureColumn('week_assignments', 'court', 'INTEGER NOT NULL DEFAULT 1');
// "Manually picked by an admin" flag (Kyle, 2026-09-07) — set only by the
// plain Reassign-to-roster-player action, so the resulting reminder/follow-up
// email can skip the Need-a-sub button / found-a-sub line (see email.js).
// A plain literal integer default IS legal in ALTER TABLE ADD COLUMN (unlike
// a function-call default like datetime('now'), which crashed production
// once already — see the broader_sub_list.created_at fix elsewhere in this
// file), so this one's safe as a single ensureColumn call with no separate
// backfill needed.
ensureColumn('week_assignments', 'manually_placed', 'INTEGER NOT NULL DEFAULT 0');

// admin_confirmed (Kyle, 2026-09-15) — set only by the admin session-detail
// page's "Mark confirmed" button, so playerBehaviorStats.js's
// confirmTimingStats() can report it apart from a player's own confirm
// click. See schema.sql's comment on this column for the full reasoning.
// Every existing confirmed row simply defaults to 0 (an admin-vouched
// confirm before this column existed can't be told apart from a real
// player click after the fact, and there's no reliable way to backfill it).
ensureColumn('week_assignments', 'admin_confirmed', 'INTEGER NOT NULL DEFAULT 0');

// replaces_assignment_id (Kyle, 2026-09-07): points a sub's own row at the
// original, now-subbed_out row it replaced — see schema.sql's comment. Bare
// nullable column, no default needed (every existing row is simply unset,
// which is exactly what an ordinary non-sub row should be). Never backfilled
// for pre-existing sub pairs — sessionHelper.js's orderAssignmentsWithSubGroups()
// falls back to a same-team/court guess for those instead of risking a wrong
// guess baked permanently into the database.
ensureColumn('week_assignments', 'replaces_assignment_id', 'INTEGER REFERENCES week_assignments(id)');
// Archiving a session (hides it from the dashboard/session picker without
// deleting anything) — every existing row predates this, so NULL (not
// archived) is exactly the right default for them.
ensureColumn('sessions', 'archived_at', 'TEXT');
// Per-session toggle to pause the automatic reminder/follow-up cron pass
// (e.g. while testing) without touching manual sends — every existing row
// predates this, so defaulting to 1 (enabled) preserves current behavior.
ensureColumn('sessions', 'reminders_enabled', 'INTEGER NOT NULL DEFAULT 1');
// Cross-session double-booking guard: lets the admin rank which session a
// player belongs to on a given day when two of their sessions collide (same
// match_day_of_week, overlapping date ranges). NULL = unresolved (existing
// rows all predate this, so every one of them defaults to "not yet decided",
// which is the correct, safe default — see scheduleRun.js's
// crossSessionPriorityExclusions()). Lower number = higher priority.
ensureColumn('session_players', 'priority', 'INTEGER');
// Snapshot of who proposed a swap, taken at proposal time — lets
// respondToSwap() detect if an admin reassigned either side's slot to a
// different player while the request was still pending, instead of silently
// executing a trade with whoever currently happens to hold the assignment
// (see swapFlow.js's identity-drift check). Existing rows all predate this
// column and get NULL, which the check treats as "can't verify, refuse" —
// safe by construction since NULL never equals a real player id.
ensureColumn('swap_requests', 'initiator_player_id', 'INTEGER');
// Overdue-swap nudge + expiry (Kyle, 2026-08-11): a pending swap had no
// timeout or escalation at all — if the target player never responded, it
// just sat there forever with no admin visibility. `nudge_token`/`nudged_at`
// track the one-time reminder email (see nudgeOverdueSwaps()); existing rows
// get NULL, which correctly means "no nudge sent yet" for a pre-migration
// swap that's already pending. `status` also gains an 'expired' value handled
// entirely in application code (see expireStaleSwaps()), so no schema change
// was needed for that part.
ensureColumn('swap_requests', 'nudge_token', 'TEXT');
ensureColumn('swap_requests', 'nudged_at', 'TEXT');

// original_target snapshots each player's configured target the FIRST time
// they're enrolled in a session (see admin.js's roster-save route) and is
// never touched again, even if target_games is later edited down to "just
// the remaining open weeks" after a mid-season roster change. Kyle,
// 2026-08-13: target_games itself has no history — overwriting it mid-season
// silently loses the original number, which the Stats page inherited too
// since it reads that same column. Existing rows predate this column and
// have no way to know what their true original number was (only today's
// current target_games survives), so treating "whatever's currently there"
// as the best available approximation is the right one-time backfill rather
// than leaving it NULL forever. The WHERE clause makes this safe to run on
// every boot rather than needing a one-time guard: after the first boot every
// row has a value, and every new enrollment sets it at INSERT time (never
// UPDATE), so nothing here ever matches again in practice.
ensureColumn('session_players', 'original_target', 'INTEGER');
raw.exec('UPDATE session_players SET original_target = target_games WHERE original_target IS NULL');

// Explicit "lock this schedule" action (Kyle, 2026-08-13) — distinct from the
// automatic draft -> scheduled status flip that already happens on the FIRST
// "Schedule these players" click. Between that first click and whenever the
// admin is actually confident the schedule is final, blackout dates can still
// change (admin overrides bypass the player-facing lock), the roster can
// still be edited, and another session's roster can shift the double-booking
// picture — so "a schedule technically exists" and "this is the version
// we're standing behind" are genuinely different moments. Nullable TEXT
// timestamp, manually set/cleared via a button (not automatic — matches every
// other judgment call in this app), existing rows all predate this and
// default to NULL (not locked), which is the correct, safe default. Locking
// does not restrict any further edits — it's a marker and, eventually, a gate
// for behavior that should wait for a stable schedule (see the deferred
// sub-needed notification under discussion in CLAUDE.md), not a hard block.
ensureColumn('sessions', 'schedule_locked_at', 'TEXT');

// Admin-flagged sub requests (Kyle, 2026-08-13): an admin can now flag a
// player's slot as needing a sub directly from the Reassign dropdown ("Needs
// a sub"), for a hard conflict discovered before the player's gotten to it
// themselves — deliberately rare/edge-case, per Kyle ("admins should really
// not be touching the player schedule except for edge cases"). Unlike the
// player-initiated flow, this sends no email of any kind at the moment it's
// flagged — not even to the affected player — and the candidate fan-out
// itself waits for that week's normal reminder time rather than firing
// immediately. `initiated_by` records which path created the request (shown
// nowhere player-facing, just for admin/audit clarity); `fanout_sent_at`
// is the actual gate cron.js's processReminders() checks. Existing rows
// predate both columns and were all self-service by definition (this feature
// didn't exist yet), so they backfill to 'player' / fanout already sent at
// creation time — the correct history for a request that, at the time, could
// only have come from a player and could only have emailed immediately.
ensureColumn('sub_requests', 'initiated_by', "TEXT NOT NULL DEFAULT 'player'");
ensureColumn('sub_requests', 'fanout_sent_at', 'TEXT');
raw.exec(`UPDATE sub_requests SET fanout_sent_at = created_at WHERE fanout_sent_at IS NULL AND initiated_by = 'player'`);

// requesting_player_id (Kyle, 2026-08-28, found by tracing a Stats page
// question): snapshots who was actually on a week_assignment at the moment a
// sub_requests row was created, so the Stats page's Sub History table can
// keep showing who a past request was really about even after that same
// slot gets reassigned or swapped to someone else later (the admin's Reassign
// tool, the joint conflict resolver, etc.) — without this, that table
// resolved "who this was about" via the assignment's *current* player_id,
// which silently relabels old history under the new occupant's name. Same
// "capture identity before it can drift" reasoning as
// swap_requests.initiator_player_id.
//
// Existing rows predate this column and there's no reliable way to recover
// who was actually on the assignment at the time historically (only who's on
// it now) — so this is a best-effort backfill, not a true correction: it
// fills every existing row with the assignment's *current* player_id, which
// is exactly the same (slightly wrong, for any slot reassigned since) answer
// the Stats page already gave before this fix. Going forward, every new
// sub_requests row captures the real value at creation time, so this
// limitation only ever applies to rows that already existed before this
// migration ran.
ensureColumn('sub_requests', 'requesting_player_id', 'INTEGER REFERENCES players(id)');
raw.exec(`
  UPDATE sub_requests SET requesting_player_id = (
    SELECT wa.player_id FROM week_assignments wa WHERE wa.id = sub_requests.week_assignment_id
  ) WHERE requesting_player_id IS NULL
`);

// Club name/court info used to be one global value in app_settings; now each
// session has its own (a single install can run sessions for different
// clubs/locations). For an install that already had the old global columns
// set, backfill every session with that value on the boot where the new
// per-session columns first get added, so upgrading doesn't silently blank
// out something that was already configured. Brand new installs never had
// the old app_settings columns in the first place (schema.sql no longer
// creates them), so hasColumn() guards against reading columns that don't
// exist there.
const sessionsGotClubCol = ensureColumn('sessions', 'club_name', "TEXT NOT NULL DEFAULT ''");
const sessionsGotCourtCol = ensureColumn('sessions', 'court_info', "TEXT NOT NULL DEFAULT ''");
if ((sessionsGotClubCol || sessionsGotCourtCol) && hasColumn('app_settings', 'club_name')) {
  const old = raw.prepare('SELECT club_name, court_info FROM app_settings WHERE id = 1').get();
  if (old && (old.club_name || old.court_info)) {
    raw.prepare('UPDATE sessions SET club_name = ?, court_info = ?').run(old.club_name || '', old.court_info || '');
  }
}

ensureColumn('sessions', 'color', 'TEXT');

// Follow-up nudge timing (Kyle, 2026-08-27): replaced cron.js's old fixed
// FOLLOW_UP_TIME='09:00' constant (same wall-clock time for every session,
// every match) with a per-session lead-hours field, same shape as
// admin_report_lead_hours/adhoc_*_lead_hours below. Every existing row
// predates this column, so the DEFAULT 27 here is what they silently start
// using — chosen because it was Kyle's own request (a 26-28 hour window) and
// because it's *not* a clean 24h/48h boundary, so a session left unconfigured
// still gets the actual behavior asked for, not a placeholder.
ensureColumn('sessions', 'follow_up_lead_hours', 'INTEGER NOT NULL DEFAULT 27');

// Admin pre-match status report (Kyle, 2026-08-26): a per-session, opt-in
// digest emailed to the admin's own address(es) a configurable number of
// hours before each week's match, summarizing who's confirmed/unconfirmed/
// needs a sub/subbed out/swapped that week — see adminReport.js and
// "Admin pre-match status report" in CLAUDE.md. Every existing row predates
// this, so NULL (feature off) is the correct default; admin_report_lead_hours
// defaults to 8 (Kyle's own example) even though the feature is off until an
// address is actually entered, so it's already sensible the moment someone
// fills in the email field without also having to touch this number.
ensureColumn('sessions', 'admin_report_emails', 'TEXT');
ensureColumn('sessions', 'admin_report_lead_hours', 'INTEGER NOT NULL DEFAULT 8');

// Ad-hoc pickup-game sessions (Kyle, 2026-08-12) — a second session shape
// alongside the original fairness-scheduled "regular" one. Every existing
// row predates this, so 'regular' is exactly the right default to preserve
// current behavior; the three lead-hour fields default to the exact routine
// Kyle described (56h initial invite, 30h stragglers-only reminder, 24h
// final roster/"not enough" email) so a freshly-created ad-hoc session works
// out of the box without the admin having to know to configure them. See
// "Ad-hoc sessions" in CLAUDE.md and adhocFlow.js.
ensureColumn('sessions', 'session_type', "TEXT NOT NULL DEFAULT 'regular'");
ensureColumn('sessions', 'adhoc_invite_lead_hours', 'INTEGER NOT NULL DEFAULT 56');
ensureColumn('sessions', 'adhoc_reminder_lead_hours', 'INTEGER NOT NULL DEFAULT 30');
ensureColumn('sessions', 'adhoc_final_lead_hours', 'INTEGER NOT NULL DEFAULT 24');

// One-time seed: before session_sub_list existed, EVERY sub request in the
// app escalated to the ENTIRE broader_sub_list, regardless of session — see
// "Per-session sub list" in CLAUDE.md. Upgrading an install that already
// has real sessions and a real master list, with session_sub_list still
// empty (never touched), assigns every existing master-list person to
// every existing session once, so escalation keeps working exactly as it
// did before this feature existed until the admin deliberately narrows it
// per session. A brand new install has nothing to preserve (no sessions or
// master list yet), so this is a no-op there.
const sessionSubListCount = raw.prepare('SELECT COUNT(*) as n FROM session_sub_list').get().n;
if (sessionSubListCount === 0) {
  const allSessionIds = raw.prepare('SELECT id FROM sessions').all().map((r) => r.id);
  const allSubIds = raw.prepare('SELECT id FROM broader_sub_list').all().map((r) => r.id);
  if (allSessionIds.length > 0 && allSubIds.length > 0) {
    const insertPair = raw.prepare('INSERT OR IGNORE INTO session_sub_list (session_id, broader_list_id) VALUES (?, ?)');
    for (const sessionId of allSessionIds) {
      for (const subId of allSubIds) insertPair.run(sessionId, subId);
    }
  }
}

// One-time seed: the app used to support exactly one admin, via
// ADMIN_PASSWORD_HASH in .env. Now that logins live in the `admins` table
// (so more than one person can have their own password), an upgrade with no
// rows yet gets a single "Admin" row carried over from that env var, so
// nobody's existing password stops working after this update. New admins
// after that are managed entirely from Admin -> Admins, not .env.
const adminCount = raw.prepare('SELECT COUNT(*) as n FROM admins').get().n;
if (adminCount === 0 && process.env.ADMIN_PASSWORD_HASH) {
  raw
    .prepare('INSERT INTO admins (name, password_hash, active) VALUES (?, ?, 1)')
    .run('Admin', process.env.ADMIN_PASSWORD_HASH);
}

// Name-based "My Page" URLs (Kyle, 2026-08-26): players.slug is app-level
// unique (no DB constraint — see playerSlug.js's slugTaken(), which is what
// actually enforces it on create/edit), generated once from the player's
// name and never auto-regenerated afterward so existing /me/<slug> links
// stay valid even if the name is later corrected. Every existing row
// predates this column, so backfill every NULL slug once, in a stable order
// (id ASC) so re-running this is a no-op after the first boot — same
// "unconditional WHERE-guarded backfill" pattern as original_target above.
// Collisions within the backfill itself (two players who'd generate the
// same base slug) are resolved the same way playerSlug.js resolves any
// other collision: -2, -3, ... appended, checked against both already-
// committed rows and slugs assigned earlier in this same loop.
ensureColumn('players', 'slug', 'TEXT');
{
  const { generateUniqueSlug } = require('../services/playerSlug');
  const unslugged = raw.prepare('SELECT id, name FROM players WHERE slug IS NULL ORDER BY id ASC').all();
  if (unslugged.length > 0) {
    const setSlug = raw.prepare('UPDATE players SET slug = ? WHERE id = ?');
    for (const p of unslugged) {
      setSlug.run(generateUniqueSlug(raw, p.name, p.id), p.id);
    }
  }
}

// broader_sub_list.slug (Kyle, 2026-09-01): "should we create a slug URL
// for the broader sub list so an admin could control them so there is no
// conflicts?" Same bookmarkable-URL idea as players.slug above, but
// exposed on the Broader Sub List admin page ahead of time — reserved the
// moment someone's added, rather than only generated (with no admin
// visibility) when claimSub() creates their real players row at claim
// time (see subFlow.js). Every existing row predates this column, so
// backfill every NULL slug once, same "id ASC, unconditional
// WHERE-guarded" pattern as players.slug just above — except uniqueness
// is checked against BOTH players.slug (the real namespace this value
// lands in once claimed) and every other broader_sub_list.slug, via
// generateUniqueBroaderSubSlug() — see its doc comment in playerSlug.js.
ensureColumn('broader_sub_list', 'slug', 'TEXT');
{
  const { generateUniqueBroaderSubSlug } = require('../services/playerSlug');
  const unslugged = raw.prepare('SELECT id, name FROM broader_sub_list WHERE slug IS NULL ORDER BY id ASC').all();
  if (unslugged.length > 0) {
    const setSlug = raw.prepare('UPDATE broader_sub_list SET slug = ? WHERE id = ?');
    for (const bl of unslugged) {
      setSlug.run(generateUniqueBroaderSubSlug(raw, bl.name, bl.id), bl.id);
    }
  }
}

// "I found a sub" (Kyle, 2026-09-07): a self-arranged broader_sub_list entry
// needs a created_at (so the admin Sub List page can show recent additions)
// and an added_by_player_id (so it can name who added them) — neither
// existed before this feature, so every pre-existing row gets a safe
// default: created_at backfills to "now" (the real creation date isn't
// recoverable, and this is only ever used to show/sort recent self-arranged
// additions, not for anything that depends on the true historical value),
// added_by_player_id stays NULL (correctly reads as "admin-added" for every
// row that predates this feature, which is accurate).
// NOTE: SQLite's ALTER TABLE ADD COLUMN rejects a non-constant default like
// datetime('now') outright ("Cannot add a column with non-constant
// default") even though the exact same expression is fine in CREATE TABLE
// above — this crashed every existing install on boot until fixed here.
// Add the column bare (nullable, no default) and backfill in a second step,
// same "id ASC, unconditional WHERE-guarded" pattern as players.slug/
// admins.username above.
ensureColumn('broader_sub_list', 'created_at', 'TEXT');
raw.exec(`UPDATE broader_sub_list SET created_at = datetime('now') WHERE created_at IS NULL`);
ensureColumn('broader_sub_list', 'added_by_player_id', 'INTEGER REFERENCES players(id)');

// broader_sub_list.public_name (Kyle, 2026-09-07): "we have a name field but
// we don't have the shorted public name. This makes when someone checks the
// public page, if a broader sub list filled a spot, their full name
// appears." Before this, the short public form was only ever derived on the
// fly at the moment it was actually needed (claimSub(), the sub-list
// reassign branch, and the /found-sub/:token picker all called
// deriveShortName(bl.name) inline) — correct in principle, but gave Kyle no
// way to review or fix an awkward auto-shortened name (a hyphenated last
// name, a nickname, etc.) before anyone ever actually claimed a spot. This
// column makes it a real, stored, admin-editable value instead — same
// "auto-derived but always editable" shape as broader_sub_list.slug just
// above. Every existing row predates this column, so backfill every NULL
// value once via deriveShortName(name), same "id ASC, unconditional
// WHERE-guarded" pattern as every other backfill in this file.
ensureColumn('broader_sub_list', 'public_name', 'TEXT');
{
  const { deriveShortName } = require('../services/playerName');
  const unnamed = raw.prepare('SELECT id, name FROM broader_sub_list WHERE public_name IS NULL ORDER BY id ASC').all();
  if (unnamed.length > 0) {
    const setPublicName = raw.prepare('UPDATE broader_sub_list SET public_name = ? WHERE id = ?');
    for (const bl of unnamed) {
      setPublicName.run(deriveShortName(bl.name), bl.id);
    }
  }
}

// Admin usernames (Kyle, 2026-08-29): every admin row created before this
// column existed has no username — backfill each one from their name, same
// "unconditional WHERE-guarded, id-ASC, collision-resolved" pattern as
// players.slug directly above (and for the same reason: safe to run on
// every boot, since after the first pass no row ever matches `username IS
// NULL` again). See adminUsername.js's doc comment for why this exists —
// short version, the old password-only login couldn't tell two admins with
// the same password apart, and an explicit per-admin username fixes that.
ensureColumn('admins', 'username', 'TEXT');
{
  const { generateUniqueUsername } = require('../services/adminUsername');
  const unnamed = raw.prepare('SELECT id, name FROM admins WHERE username IS NULL ORDER BY id ASC').all();
  if (unnamed.length > 0) {
    const setUsername = raw.prepare('UPDATE admins SET username = ? WHERE id = ?');
    for (const a of unnamed) {
      setUsername.run(generateUniqueUsername(raw, a.name, a.id), a.id);
    }
  }
}

// Configurable public-site title (Kyle, 2026-09-01): the "🎾 Doubles
// Schedule" brand link in the upper-left corner of every player-facing page
// (partials/header.ejs) was hardcoded — admin-only, site-wide config, same
// as timezone, so it lives on the same app_settings singleton row rather
// than a new table. Defaulted to the exact string that was hardcoded before
// this, so every existing install keeps showing the identical text until an
// admin actually changes it.
ensureColumn('app_settings', 'site_title', "TEXT NOT NULL DEFAULT '🎾 Doubles Schedule'");

// Weather forecast (Kyle, 2026-09-05) — per-session opt-in + location, so an
// existing session's emails/site widget don't suddenly start showing weather
// with no location configured. week_weather itself is a brand-new table,
// created fresh by the CREATE TABLE IF NOT EXISTS above — no backfill needed
// there, since a week with no cached forecast yet just renders nothing until
// weather.js's cron pass first populates it.
ensureColumn('sessions', 'weather_enabled', 'INTEGER NOT NULL DEFAULT 0');
ensureColumn('sessions', 'weather_lat', 'REAL');
ensureColumn('sessions', 'weather_lon', 'REAL');

// Public name vs. full name (Kyle, 2026-09-07): "In the player roster... I
// used Kyle K, or Marcus G. This is what shows up on the public screen. This is
// fine as last names are not shown, but for the broader sub list, I have full
// names called out... everywhere we have a public facing page, we should use
// the public name field. Any where we have an admin looking at it, it should
// be a full name... in emails for confirms, subs, swaps, etc... we should use
// full names." `players.name` keeps its existing meaning and values (the
// short public form) — this only adds a new, initially-blank `full_name`
// column. See src/services/playerName.js's fullName() for the read side
// (falls back to `name` when full_name hasn't been filled in yet) and
// deriveShortName() for the write side (auto-generates a public name for a
// brand-new player created from a full name only — a sub-list conversion, a
// one-time sub — see subFlow.js/admin.js).
//
// Bare/nullable, no default needed (unlike created_at above, there's no
// sensible default to backfill blindly — see the broader_sub_list match
// below for the one case where we DO know a real full name to fill in).
ensureColumn('players', 'full_name', 'TEXT');
// Kyle explicitly asked for this: "pre-fill from a matching email" so
// existing players who've already been on the broader sub list at some point
// (which has always stored full names) don't need their full name re-typed
// by hand. WHERE full_name IS NULL makes this safe to re-run on every boot —
// it only ever fills a blank, never overwrites a value an admin later edited
// on the Players page. Anyone with no broader_sub_list match at all is left
// NULL, same as a brand-new install with no data to pre-fill from.
raw.exec(`
  UPDATE players
  SET full_name = (SELECT bsl.name FROM broader_sub_list bsl WHERE bsl.email = players.email)
  WHERE full_name IS NULL
    AND EXISTS (SELECT 1 FROM broader_sub_list bsl WHERE bsl.email = players.email)
`);

// Escalation lead time (Kyle, 2026-09-08): "do we have sending out the sub
// request email to the broader sub email list hard coded to a time, or is
// that time configured in each session?" It was hard-coded (24h before match,
// same for every session) in subFlow.js's escalateOverdueRequests() — this
// makes it a per-session field like follow_up_lead_hours/
// admin_report_lead_hours above. Default 24 matches the prior hardcoded
// behavior exactly, so no existing session's timing changes on upgrade.
ensureColumn('sessions', 'escalation_lead_hours', 'INTEGER NOT NULL DEFAULT 24');

// Game scores (Kyle, 2026-09-09): "a screen where players can enter the # of
// games won during their weekly match... tally together during a session...
// a running total can be seen with a player leader board." Each player
// self-reports their own personal games-won number for their own
// week_assignments row (not a single shared team score) — see
// src/services/gameScores.js for the full read/write/lock rules and
// src/routes/public.js's GET/POST /scores for the entry screen. Three bare
// nullable columns, no default needed (every existing row simply has no
// score yet, exactly what NULL already means):
// - games_won: the player's own reported count for that week's match. NULL
//   = never entered.
// - games_won_entered_at: set once, the first time a score is saved for this
//   row — never touched again on later edits. This is what the 24-hour
//   self-service edit window (below) is measured from, not match time or
//   week-lock time, so a score entered late (days after the match) still
//   gets its own full 24h window to fix a typo.
// - games_won_updated_at: stamped on every save (including the first), so
//   the entry screen and admin session-detail page can show "last updated"
//   without a separate history table.
// Self-service editing after entry is gated by games_won_entered_at + 24h in
// gameScores.js's canPlayerEdit() — this migration only adds the columns;
// the actual lock check is pure application logic computed at request time,
// same pattern as everywhere else in this app that avoids a stored "locked"
// boolean in favor of computing it live (see e.g. weeks.locked, which IS
// stored, but that one needs to be — it also invalidates tokens and is
// checked by the cron loop, neither of which applies here).
ensureColumn('week_assignments', 'games_won', 'INTEGER');
ensureColumn('week_assignments', 'games_won_entered_at', 'TEXT');
ensureColumn('week_assignments', 'games_won_updated_at', 'TEXT');

// VESTIGIAL (Kyle, 2026-09-10, superseded the same day) — see this column's
// doc comment in schema.sql: games played turned out to be one shared
// number per match (week+court), not something each player reports
// individually, so week_court_games (created directly in schema.sql, below
// the CREATE TABLE IF NOT EXISTS block — a brand-new table needs no
// ensureColumn migration) replaced this. Left in place, never dropped, same
// additive-only philosophy as every other vestigial column in this file;
// no longer read or written.
ensureColumn('week_assignments', 'games_played', 'INTEGER');

// Per-session opt-out for the games-won feature above (Kyle, 2026-09-10):
// "is there a way to turn this off per session? If a group didn't want to
// keep the # of games, the buttons could be removed from their schedule
// page." Defaults to 1 (on) — same reasoning as manually_placed's doc
// comment above about literal-vs-function-call ALTER TABLE defaults: a
// literal default is safe, and 1 is the only safe choice here since the
// feature has already been live for every session with no way to turn it
// off, so a fresh column defaulting to 0 would silently pull the feature out
// from under every existing session's players the moment this migration
// runs. See sessionHelper.js's gamesWonEnabledForSession() (or the inline
// `session.games_won_enabled` check, for a row that's already in hand) for
// where this is actually read — admin visibility (the session-detail "Games
// won" field, both admin Stats leaderboard tables) is deliberately NOT
// gated by this flag, same "admin overrides aren't restricted by a
// player-facing toggle" pattern as reminders_enabled/weather_enabled; only
// the player-facing entry points (schedule/lookahead/My Page links, the
// group entry grid, the per-player Scores page, the public leaderboard) are.
ensureColumn('sessions', 'games_won_enabled', 'INTEGER NOT NULL DEFAULT 1');

// Player Behavior stats on the Activity Log page (Kyle, 2026-09-15): "how
// many times a player needs a sub, and how many times we find a sub within
// the roster vs. the broader sub list vs. an unknown player." Both columns
// default to 0 for every existing row, which is exactly right — neither flag
// could have been true before this migration existed, since the code that
// sets them (subFlow.js's arrangeSelfSub()) is being changed in the same
// pass. See schema.sql's own comments on these two columns for what each one
// actually captures.
ensureColumn('sub_requests', 'self_arranged', 'INTEGER NOT NULL DEFAULT 0');
ensureColumn('sub_offers', 'was_new_person', 'INTEGER NOT NULL DEFAULT 0');

// Ball duty games-won reminder (Kyle, 2026-09-15) — see schema.sql's comment
// on this column and cron.js's processScoreReminders(). Defaults to 24,
// matching Kyle's own requested default, so every existing session picks up
// the new reminder pass at the same 24h cadence rather than silently staying
// off (there's no "0 = disabled" escape hatch here, same as
// follow_up_lead_hours/admin_report_lead_hours before it — turning the whole
// reminder off means turning games_won_enabled off for the session).
ensureColumn('sessions', 'games_won_reminder_lead_hours', 'INTEGER NOT NULL DEFAULT 24');

// Season sign-ups (Kyle, 2026-09-23) — per-session tier percentages, admin-
// editable on the new Sign-ups page (src/services/signup.js). Every existing
// row predates this feature, so it defaults to exactly the numbers Kyle
// described as typical ("full time = 75%, half time = 50% and quarter time
// = 25% of the weeks") — a session nobody's touched this on yet behaves
// exactly as if an admin had filled in those three numbers themselves.
ensureColumn('sessions', 'signup_pct_full', 'INTEGER NOT NULL DEFAULT 75');
ensureColumn('sessions', 'signup_pct_half', 'INTEGER NOT NULL DEFAULT 50');
ensureColumn('sessions', 'signup_pct_quarter', 'INTEGER NOT NULL DEFAULT 25');

// Win % leaderboard qualification threshold, made per-session (Kyle,
// 2026-09-23) — was a hardcoded constant (gameScores.js's
// MIN_MATCHES_FOR_WIN_PCT) until Kyle asked whether it should be an
// admin-level parameter per session. Defaults to 2, matching the constant's
// own prior hardcoded value, so every existing session behaves identically
// until an admin actually changes it. See schema.sql's comment on this
// column and gameScores.js's MIN_MATCHES_FOR_WIN_PCT doc comment.
ensureColumn('sessions', 'min_matches_for_win_pct', 'INTEGER NOT NULL DEFAULT 2');

// ---------------------------------------------------------------------------
// Seasons + three-tier stats (Kyle, 2026-09-25) — see schema.sql's "Seasons
// and the three-tier stats model" comment for the full model. All additive:
// nothing existing is altered, and every existing session simply lands in
// one starting season below.
//
// season_id is a plain nullable INTEGER (no REFERENCES clause) so it can be
// added with ALTER TABLE on a table that already has rows; app code treats a
// NULL as "not in a season" (it still counts toward the master).
ensureColumn('sessions', 'season_id', 'INTEGER');
// "Count this session's stats toward the season leaderboard" — defaults ON.
ensureColumn('sessions', 'count_toward_season', 'INTEGER NOT NULL DEFAULT 1');
// Global master-board settings live on the single app_settings row.
ensureColumn('app_settings', 'master_stats_visible', 'INTEGER NOT NULL DEFAULT 1');
ensureColumn('app_settings', 'master_min_matches_for_win_pct', 'INTEGER NOT NULL DEFAULT 2');

// One-time backfill: sessions that predate seasons all go into a single
// starting season the admin can rename. Guarded so it only ever runs while
// there are no seasons at all — after that, admins assign seasons
// themselves and a NULL season_id is left alone.
(function backfillInitialSeason() {
  const orphans = raw.prepare('SELECT COUNT(*) AS n FROM sessions WHERE season_id IS NULL').get().n;
  const seasonCount = raw.prepare('SELECT COUNT(*) AS n FROM seasons').get().n;
  if (orphans > 0 && seasonCount === 0) {
    const info = raw.prepare("INSERT INTO seasons (name) VALUES ('Initial season (rename me)')").run();
    raw.prepare('UPDATE sessions SET season_id = ? WHERE season_id IS NULL').run(Number(info.lastInsertRowid));
  }
})();

// Thin wrapper giving a better-sqlite3-like ergonomic API (prepare().run/get/all,
// plus a convenience .exec) so the rest of the app reads the same regardless of
// which underlying driver is in use.
function normalizeParams(params) {
  // node:sqlite wants named params without the leading punctuation stripped, and
  // does not accept `undefined` — convert to null.
  if (Array.isArray(params)) {
    return params.map((p) => (p === undefined ? null : p));
  }
  if (params && typeof params === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(params)) {
      out[k] = v === undefined ? null : v;
    }
    return out;
  }
  return params;
}

const db = {
  raw,
  prepare(sql) {
    const stmt = raw.prepare(sql);
    return {
      run: (...args) => stmt.run(...args.map(normalizeParams)),
      get: (...args) => stmt.get(...args.map(normalizeParams)),
      all: (...args) => stmt.all(...args.map(normalizeParams)),
    };
  },
  exec(sql) {
    return raw.exec(sql);
  },
  transaction(fn) {
    return (...args) => {
      raw.exec('BEGIN');
      try {
        const result = fn(...args);
        raw.exec('COMMIT');
        return result;
      } catch (err) {
        raw.exec('ROLLBACK');
        throw err;
      }
    };
  },
};

module.exports = db;
