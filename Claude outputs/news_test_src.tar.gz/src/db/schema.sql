-- Doubles Scheduler — SQLite schema
-- Matches the data model in Technical_Architecture.md

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS players (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL, -- the PUBLIC name, shown on every unauthenticated page (schedule, lookahead, My Page, PDF, calendar, public stats) — e.g. "Kyle K", first name + last initial, matching how the roster has always been entered. See full_name below and src/services/playerName.js.
  email         TEXT NOT NULL UNIQUE,
  active        INTEGER NOT NULL DEFAULT 1,
  slug          TEXT,  -- URL-safe name-based id for "My Page" (/me/<slug>) links, e.g. 'brian-b'. App-level uniqueness only (see playerSlug.js) — generated once at creation and never auto-regenerated on rename, so existing bookmarks/emails/calendar links keep working. NULL only briefly for a pre-migration row before db/index.js's one-time backfill runs. Always derived from the public `name` above, never from full_name — unaffected by the full-name split (Kyle, 2026-09-07).
  full_name     TEXT  -- the real full name (Kyle, 2026-09-07): "for the broader sub list, I have full names called out... everywhere we have a public facing page, we should use the public name field. Anywhere admin is looking at it, it should be a full name... in emails... we should use full names as that's a trusted system." Shown on every admin page and in every email; NULL until an admin fills it in on the Players page, in which case src/services/playerName.js's fullName() falls back to the public `name` so nothing renders blank.
);

-- Single-row global settings table
CREATE TABLE IF NOT EXISTS admins (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  name          TEXT NOT NULL,
  username      TEXT,
  email         TEXT,
  password_hash TEXT NOT NULL,
  active        INTEGER NOT NULL DEFAULT 1,
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS app_settings (
  id            INTEGER PRIMARY KEY CHECK (id = 1),
  timezone      TEXT NOT NULL DEFAULT 'America/Chicago',
  site_title    TEXT NOT NULL DEFAULT '🎾 Doubles Schedule'   -- admin-editable brand text, upper-left of every public page (Settings)
);
-- Deliberately does NOT list site_title here: this INSERT runs unconditionally
-- on every boot (raw.exec(schema) in db/index.js), before ensureColumn() ever
-- gets a chance to add that column to an existing installation's app_settings
-- table — referencing it here crashed the whole app on boot for any existing
-- DB, since the real table didn't have the column yet at the moment this runs.
-- A fresh install's app_settings row already gets '🎾 Doubles Schedule' for
-- free from the column's own DEFAULT above; an existing row gets it from
-- ensureColumn's backfill further down in db/index.js.
INSERT OR IGNORE INTO app_settings (id, timezone) VALUES (1, 'America/Chicago');

CREATE TABLE IF NOT EXISTS sessions (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  name                TEXT NOT NULL,
  start_date          TEXT NOT NULL,          -- ISO date
  end_date            TEXT NOT NULL,          -- ISO date
  status              TEXT NOT NULL DEFAULT 'draft', -- draft | scheduled | active | completed
  lookahead_weeks     INTEGER NOT NULL DEFAULT 4,
  match_day_of_week   INTEGER NOT NULL,       -- 0=Sun .. 6=Sat
  match_time          TEXT NOT NULL,          -- 'HH:MM' 24h, local to app_settings.timezone
  reminder_time       TEXT NOT NULL,          -- 'HH:MM' 24h
  reminder_days_before INTEGER NOT NULL DEFAULT 2,
  follow_up_lead_hours INTEGER NOT NULL DEFAULT 27, -- hours before match_time the one automatic follow-up nudge fires for anyone still 'scheduled' (replaced a fixed 9am-morning-of time — Kyle, 2026-08-27: wanted this reachable during work hours the day before, not the morning of, since 9am-morning-of can already be mid-workday for an evening match)
  reminders_enabled  INTEGER NOT NULL DEFAULT 1, -- 0 pauses the automatic reminder + follow-up cron pass for this session only; manual Resend/Send reminders now are unaffected either way
  courts              INTEGER NOT NULL DEFAULT 1,
  players_per_week    INTEGER NOT NULL DEFAULT 4,
  club_name           TEXT NOT NULL DEFAULT '',   -- per-session: shown in this session's outbound emails, since different sessions can be different clubs/locations
  court_info          TEXT NOT NULL DEFAULT '',   -- per-session: e.g. "Court 3" or "North courts 1-2"
  color               TEXT,    -- optional hex color (e.g. '#0969da') the admin can set to visually tell same-club/same-time sessions apart; NULL falls back to a deterministic palette pick keyed by session id (see email.js's sessionColor())
  schedule_conflicts  TEXT,    -- JSON array of conflict objects from the last "Schedule these players" run, if infeasible
  archived_at         TEXT,    -- NULL = active/visible; set = hidden from the dashboard and public session picker, but not deleted (see "Archiving" in CLAUDE.md)
  session_type        TEXT NOT NULL DEFAULT 'regular', -- 'regular' | 'adhoc' — see "Ad-hoc sessions" in CLAUDE.md. Fixed for the life of a session; everything downstream (session detail page, dashboard section, cron behavior, which emails fire) branches on this.
  adhoc_invite_lead_hours   INTEGER NOT NULL DEFAULT 56, -- adhoc only: hours before match_time the first sign-up invite goes out to the whole roster
  adhoc_reminder_lead_hours INTEGER NOT NULL DEFAULT 30, -- adhoc only: hours before match_time a reminder goes to whoever on the roster hasn't signed up yet, but only if there's currently an incomplete trailing group (not a multiple of 4)
  adhoc_final_lead_hours    INTEGER NOT NULL DEFAULT 24, -- adhoc only: hours before match_time full courts get a "here's your court" email and any leftover incomplete group gets a "not enough signed up" email
  schedule_locked_at  TEXT,    -- NULL = not yet finalized; set manually via "Lock this schedule" once the admin is confident the schedule is done shifting — distinct from `status` leaving 'draft', which happens automatically on the first "Schedule these players" click. Doesn't restrict further edits; a marker/gate for behavior that should wait for a stable schedule. See "Lock this schedule" in CLAUDE.md.
  admin_report_emails      TEXT,    -- regular sessions only: comma-separated admin address(es) that get a pre-match status report for each week (who's confirmed/unconfirmed/needs a sub/subbed out/swapped). NULL/blank = feature off for this session. See "Admin pre-match status report" in CLAUDE.md.
  admin_report_lead_hours  INTEGER NOT NULL DEFAULT 8, -- hours before match_time the status report above goes out
  escalation_lead_hours    INTEGER NOT NULL DEFAULT 24, -- hours before match_time an unfilled sub request escalates from the original 5-player roster fan-out to this session's broader sub list (session_sub_list) — see subFlow.js's escalateOverdueRequests(). Was hardcoded at 24 for every session until Kyle asked (2026-09-08) whether it was per-session configurable.
  weather_enabled     INTEGER NOT NULL DEFAULT 0, -- per-session opt-in (Kyle, 2026-09-05) for the weather forecast widget/email block — off by default so an existing session doesn't suddenly start showing/emailing weather with no location configured. See "Weather forecast" in CLAUDE.md and src/services/weather.js.
  weather_lat         REAL,    -- per-session (not global) location for the forecast lookup — matches club_name/court_info's existing per-session pattern, since different sessions can be at different clubs. NULL = not configured; weather.js's cron pass skips a session until both lat and lon are set even if weather_enabled is on.
  weather_lon         REAL,
  games_won_enabled  INTEGER NOT NULL DEFAULT 1, -- per-session opt-out (Kyle, 2026-09-10) for the games-won leaderboard feature — defaults ON since it's a fun extra some groups won't want. Gates only the PLAYER-facing surfaces (schedule/lookahead/My Page links, the group entry grid, the per-player Scores page, the public leaderboard); the admin session-detail "Games won" field and both admin Stats leaderboard tables are never gated by this, same "admin isn't restricted by a player-facing toggle" pattern as reminders_enabled/weather_enabled. See db/index.js's ensureColumn() doc comment for why the default must be 1, not 0.
  games_won_reminder_lead_hours INTEGER NOT NULL DEFAULT 24, -- per-session (Kyle, 2026-09-15): hours after match_time cron.js's processScoreReminders() waits before emailing that week's ball-duty player, if any player who was scheduled to play still has no games_won entered by then. Same "configurable, not hardcoded" pattern as follow_up_lead_hours/admin_report_lead_hours/escalation_lead_hours above. Only relevant while games_won_enabled is on for this session — see that column's own comment for what it gates.
  min_matches_for_win_pct INTEGER NOT NULL DEFAULT 2, -- per-session (Kyle, 2026-09-23): minimum matches scored before a player appears in the ranked Win % Leaderboard on /leaderboard, rather than the "still building a sample" list below it — was a hardcoded constant (gameScores.js's MIN_MATCHES_FOR_WIN_PCT) until Kyle asked whether it should be admin-configurable per session, same "configurable, not hardcoded" pattern as every other threshold on this table. The all-time win% board is cross-session with no single session that "owns" it, so public.js's /leaderboard route applies whichever session is currently selected in the session picker as the cutoff — see gameScores.js's MIN_MATCHES_FOR_WIN_PCT doc comment for the full reasoning.
  created_at          TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS session_players (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id        INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  player_id         INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  target_games      INTEGER NOT NULL,
  original_target   INTEGER, -- snapshot of target_games the first time this player was enrolled; never touched again, even if target_games is later edited down to "remaining open weeks" mid-season — see db/index.js
  role              TEXT NOT NULL DEFAULT 'regular',
  priority          INTEGER,  -- cross-session double-booking guard: lower = higher priority when this player's sessions collide on the same day; NULL = not yet decided (see scheduleRun.js)
  UNIQUE(session_id, player_id)
);

CREATE TABLE IF NOT EXISTS blackout_dates (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  player_id     INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  date          TEXT NOT NULL,   -- ISO date
  source        TEXT NOT NULL DEFAULT 'self', -- self | admin
  UNIQUE(session_id, player_id, date)
);

-- Per-session, per-pair hard constraints for the scheduling engine (Kyle,
-- 2026-09-23): "never_together" means the two players are never scheduled
-- the same week (whether on the same team, opposing teams, or even a
-- different court in a multi-court week — see scheduler/engine.js's
-- countWeekViolations); "always_together" means they're always scheduled
-- the exact same weeks as each other. Session-scoped (not global like
-- blackout_dates) because who can/must play with whom is naturally a
-- per-session thing (Kyle: different sessions can be entirely different
-- friend groups), unlike a blackout date which is a fact about a real
-- calendar day. player_a_id/player_b_id are always stored with the lower
-- player id first (enforced in the admin route, not here) so a given pair
-- can't be entered twice in reversed order under the same type.
CREATE TABLE IF NOT EXISTS player_constraints (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  player_a_id   INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  player_b_id   INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  type          TEXT NOT NULL, -- never_together | always_together
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(session_id, player_a_id, player_b_id, type)
);

-- Season sign-ups (Kyle, 2026-09-23): "Before blackout dates are sent out, a
-- player who is going to be on the roster can sign up for a session and
-- declare how much they want to play. The percentages need to be defined by
-- an admin of a session. Typically they are full time = 75%, half time =
-- 50% and quarter time = 25% of the weeks." Self-service, percentage-based
-- alternative to the admin hand-typing every player's target_games on
-- session_form.ejs — see "Season sign-ups" in CLAUDE.md for the full design
-- and src/services/signup.js for the percentage-to-weeks math.
--
-- Deliberately kept separate from session_players (the real roster) rather
-- than writing target_games directly: a player's own tier choice is a
-- declaration of intent, not automatically the final number — the admin
-- reviews the whole session's sign-ups (do they add up to the available
-- slots?) and explicitly applies them, same "player proposes, admin
-- disposes" shape as everything else self-service in this app (blackout
-- dates are the one exception, and even that one is a deliberate, documented
-- product tradeoff — see "Blackout dates" below).
--
-- Which players even see a sign-up option is the admin's own candidate list
-- (session_signup_candidates), not "every active player in the system" —
-- Kyle's own phrasing was "a player who is going to be on the roster",
-- mirroring how the ad-hoc roster's invite list already works.
CREATE TABLE IF NOT EXISTS session_signup_candidates (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  player_id     INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  UNIQUE(session_id, player_id)
);

-- One row per player's current declared commitment for a session. `weeks` is
-- computed server-side at submit time (percentage x this session's total
-- match weeks, rounded to the nearest whole week — never trust a
-- client-submitted number) and re-derived from scratch on every save, so it
-- always reflects the tier percentages in effect at the moment of that save,
-- not whatever they were when the player first signed up. `applied_at` is
-- NULL until the admin's "Apply to roster" action copies `weeks` into
-- session_players.target_games (see signup.js's applySignupsToRoster()) —
-- and is reset back to NULL any time this row is saved again after that, so
-- the admin review page can tell "applied and unchanged since" apart from
-- "changed since the last apply, needs re-applying" without a separate
-- history table.
CREATE TABLE IF NOT EXISTS session_signups (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  player_id     INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  tier          TEXT NOT NULL, -- 'full' | 'half' | 'quarter'
  weeks         INTEGER NOT NULL,
  applied_at    TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(session_id, player_id)
);
CREATE INDEX IF NOT EXISTS idx_signup_candidates_session ON session_signup_candidates(session_id);
CREATE INDEX IF NOT EXISTS idx_signups_session ON session_signups(session_id);

-- VESTIGIAL as of the removal of the blackout-date email-confirmation step
-- (POST /blackout now writes straight to blackout_dates) — left in place,
-- never dropped, per this app's additive-only migration philosophy. Nothing
-- reads or writes this table anymore; kept only so an existing install that
-- happens to have a stale row here doesn't hit a missing-table error.
CREATE TABLE IF NOT EXISTS blackout_pending (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  player_id     INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  dates_json    TEXT NOT NULL,   -- JSON array of ISO dates selected, awaiting confirmation
  token         TEXT UNIQUE NOT NULL, -- SHA-256 hash of the raw token; raw value only ever exists in the emailed link
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(session_id, player_id) -- a new submission replaces any not-yet-confirmed one for that player
);

CREATE TABLE IF NOT EXISTS broader_sub_list (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  name                TEXT NOT NULL,  -- always the person's real, full name (Kyle, 2026-09-07 — see public_name below)
  email               TEXT NOT NULL UNIQUE,
  slug                TEXT,  -- admin-editable "My Page" slug reserved ahead of time (Kyle, 2026-09-01) — used directly by claimSub() the moment this person claims a sub and becomes a real players row. See playerSlug.js's broaderSubSlugTaken()/generateUniqueBroaderSubSlug().
  public_name         TEXT,  -- admin-editable short public name (Kyle, 2026-09-07): pre-filled from deriveShortName(name) at creation/backfill, but always the real stored value used the moment this person actually fills a spot — never re-derived on the fly after that, so an admin edit here always sticks. See playerName.js's deriveShortName().
  created_at          TEXT NOT NULL DEFAULT (datetime('now')),
  added_by_player_id  INTEGER REFERENCES players(id)  -- NULL when an admin added this row directly (Admin -> Sub List); set when a player added them via "I found a sub" (see subFlow.js's arrangeSelfSub()) — lets the admin Sub List page flag a self-arranged entry worth reviewing (name/slug cleanup, see CLAUDE.md's "Found your own sub" section).
);

-- Which master-list subs apply to which session (Kyle, 2026-08-13): the
-- broader_sub_list above is the whole pool of people willing to sub at all;
-- this join table is each session's own subset of that pool — only these
-- people get escalation emails when one of *this* session's sub requests
-- goes unanswered, not the entire master list. See subFlow.js's
-- escalateOverdueRequests() and "Per-session sub list" in CLAUDE.md.
CREATE TABLE IF NOT EXISTS session_sub_list (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id        INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  broader_list_id   INTEGER NOT NULL REFERENCES broader_sub_list(id) ON DELETE CASCADE,
  UNIQUE(session_id, broader_list_id)
);

-- Kyle, 2026-09-02: "why don't we allow a session's sub list to pull and
-- select players from both the all players list and also the broader sub
-- list?" -- session_sub_list above only ever drew from broader_sub_list, so
-- making one session's roster available as another session's sub pool (the
-- 16-players/two-sessions-of-8 scenario discussed the night before) meant
-- manually duplicating each person into broader_sub_list by hand, kept in
-- sync with nothing. This is the second, sibling join table: real players
-- assigned directly as a session's sub candidates, no broader_sub_list
-- detour needed. See subFlow.js's sessionSubList(), which now merges rows
-- from both tables into one combined candidate list.
CREATE TABLE IF NOT EXISTS session_sub_players (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id    INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  player_id     INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  UNIQUE(session_id, player_id)
);

CREATE TABLE IF NOT EXISTS weeks (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id            INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  week_number           INTEGER NOT NULL,
  match_date            TEXT NOT NULL,  -- ISO date
  locked                INTEGER NOT NULL DEFAULT 0,
  ball_duty_player_id   INTEGER REFERENCES players(id),
  needs_attention        INTEGER NOT NULL DEFAULT 0, -- flagged infeasible by scheduler
  notes                 TEXT,
  UNIQUE(session_id, week_number)
);

CREATE TABLE IF NOT EXISTS week_assignments (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  week_id         INTEGER NOT NULL REFERENCES weeks(id) ON DELETE CASCADE,
  player_id       INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  team            TEXT NOT NULL,  -- 'A' | 'B'
  court           INTEGER NOT NULL DEFAULT 1, -- which physical court this team pair is on, for multi-court sessions
  is_sub          INTEGER NOT NULL DEFAULT 0,
  status          TEXT NOT NULL DEFAULT 'scheduled', -- scheduled | confirmed | needs_sub | subbed_out
  token           TEXT UNIQUE, -- vestigial as of the multi-token redesign — see week_assignment_tokens. Left in place (never dropped) per this app's additive-only migration philosophy; no longer read.
  token_used_at   TEXT, -- last time ANY token for this assignment was used (any row in week_assignment_tokens)
  confirmed_at    TEXT,
  manually_placed INTEGER NOT NULL DEFAULT 0, -- set by the plain Reassign-to-roster-player action (Kyle, 2026-09-07) — an admin manually picked this player for this slot, as opposed to the scheduler generating it. Suppresses the Need-a-sub button / "I found a sub" line on this assignment's reminder+follow-up emails (see email.js) since an admin-arranged placement shouldn't invite a player to self-service out of it the same way a normal scheduled slot does.
  admin_confirmed INTEGER NOT NULL DEFAULT 0, -- set only by the admin session-detail page's "Mark confirmed" button (Kyle, 2026-09-15: "add an 'admin confirmed' column where the admin confirms a player by the admin panel") — distinguishes an admin vouching for a player directly (they told the admin some other way, e.g. a phone call) from the player actually clicking their own Confirm link. Both set status='confirmed'/confirmed_at the same way; this flag is purely so playerBehaviorStats.js's confirmTimingStats() can report admin-confirmed separately from "confirmed on 1st/2nd reminder," which are meant to measure the PLAYER's own responsiveness. Not set by the one-time-sub/sub-list-reassign/Correct-player flows, which also write status='confirmed' directly — those are placing a substitute, not confirming an already-scheduled player, a different action Kyle didn't ask to track here.
  replaces_assignment_id INTEGER REFERENCES week_assignments(id), -- set on a sub's own new row at the moment they take over a slot (claimSub(), and the admin Reassign route's "one-time sub" and "sub list" branches) — points at the original, now-subbed_out row they replaced. Nullable/unset for every ordinary (non-sub) row. Lets the admin session-detail page show a sub indented directly under who they replaced instead of a flat, ambiguous list (Kyle, 2026-09-07) — see sessionHelper.js's orderAssignmentsWithSubGroups(). Never set retroactively for rows that predate this column; that display falls back to a same-team/court guess instead (see that function's doc comment).
  games_won             INTEGER, -- Kyle, 2026-09-09: self-reported "games won" for a player's own week — see src/services/gameScores.js. NULL = never entered. Each player enters their own number (not a single shared team score), so this lives on the per-player assignment row rather than a per-team/week table.
  games_won_entered_at  TEXT, -- set once, the first time a score is saved for this row — never touched again on later edits. The player's 24-hour self-service edit window (gameScores.js's canPlayerEdit()) is measured from this, not from match time or week-lock time.
  games_won_updated_at  TEXT, -- stamped on every save (including the first) — "last updated" display, no separate history table.
  games_played          INTEGER, -- VESTIGIAL (Kyle, 2026-09-10, superseded same day) — the very first cut of the games-played denominator lived here, per-player. Kyle then clarified games played is really a property of the WHOLE match (one shared number for all 4 players on a court that week, entered once), not something each player reports separately — see week_court_games below, which replaced this. Left in place, never dropped, per this app's additive-only migration philosophy (same as the token column's own vestigial note above); no longer read or written by any route.
  UNIQUE(week_id, player_id)
);

-- Shared "games played" total for one match (Kyle, 2026-09-10, replacing the
-- short-lived per-player week_assignments.games_played above): all 4 players
-- on a given court in a given week play the same match, so there's exactly
-- ONE real "games played" number for that week+court, not four individually-
-- reported ones — entered once (by any player, via either scores entry
-- page, or by an admin) and shared by everyone who played that match when
-- computing win % (games_won / games_played) in gameScores.js's
-- sessionWinPercentLeaderboard()/overallWinPercentLeaderboard(). Keyed by
-- (week_id, court) rather than week_id alone so multi-court sessions
-- (players_per_week > 4) still get a correct, independent total per court —
-- this collapses to "once per week" for the common single-court case.
CREATE TABLE IF NOT EXISTS week_court_games (
  id                       INTEGER PRIMARY KEY AUTOINCREMENT,
  week_id                  INTEGER NOT NULL REFERENCES weeks(id) ON DELETE CASCADE,
  court                    INTEGER NOT NULL DEFAULT 1,
  games_played             INTEGER, -- NULL = never entered yet
  games_played_entered_at  TEXT, -- set once, the first time this is saved — same 24h-self-service-window pattern as week_assignments.games_won_entered_at, via gameScores.js's canEditGamesPlayed()
  games_played_updated_at  TEXT, -- stamped on every save, including the first
  UNIQUE(week_id, court)
);

-- Replaces the single week_assignments.token column. Multiple tokens can be
-- valid for the same assignment at once (e.g. the original reminder link and
-- a later follow-up nudge's link both work), so a player who goes back to an
-- older-but-still-recent email doesn't hit a dead "Link not found" page. Rows
-- are deleted (not just marked used) when they should stop working: when the
-- assignment's status leaves scheduled/confirmed (see tokenStore.js), or when
-- the whole week locks because match time has passed (cron.processWeekLocking).
CREATE TABLE IF NOT EXISTS week_assignment_tokens (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  week_assignment_id    INTEGER NOT NULL REFERENCES week_assignments(id) ON DELETE CASCADE,
  token                 TEXT UNIQUE NOT NULL, -- SHA-256 hash of the raw token; raw value only ever exists in the emailed link
  created_at            TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS sub_requests (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  week_assignment_id    INTEGER NOT NULL REFERENCES week_assignments(id) ON DELETE CASCADE,
  status                TEXT NOT NULL DEFAULT 'open', -- open | filled | escalated | unfilled | resolved_manually | resolved_double_booking (see subFlow.js's closeActiveSubRequestForAssignment() — the latter, added Kyle 2026-09-10, is the joint conflict resolver closing this out by moving players between weeks rather than an admin finding a real substitute; excluded from the Stats page's Sub History table for that reason)
  created_at            TEXT NOT NULL DEFAULT (datetime('now')),
  escalated_at          TEXT,
  initiated_by          TEXT NOT NULL DEFAULT 'player', -- 'player' | 'admin' — see subFlow.js's adminFlagNeedsSub()
  fanout_sent_at        TEXT, -- NULL until the candidate roster has actually been emailed. Self-service requests set this immediately (see fanOutSubRequest()); an admin-flagged request leaves it NULL until cron.js's processReminders() reaches that week's normal reminder time, so the flag itself never emails anyone by surprise.
  requesting_player_id  INTEGER REFERENCES players(id), -- snapshot of who was on the assignment at request-creation time, same "capture identity before it can drift" reasoning as swap_requests.initiator_player_id. Without this, the Stats page's Sub History table would resolve "who this was about" via the assignment's *current* player_id, which silently relabels old history under a new name once that slot is later reassigned/swapped.
  self_arranged         INTEGER NOT NULL DEFAULT 0 -- set only by arrangeSelfSub() ("I found a sub" — one specific named candidate), never by createSubRequest()'s normal fan-out or adminFlagNeedsSub(). Lets the Activity Log's Player Behavior stats (Kyle, 2026-09-15) count "found their own sub" separately from "waited on the app's fan-out" without re-deriving it from sub_offers row counts, which stops being reliable once a self-arranged request later escalates (it can gain more offers, same as any other still-open request — see arrangeSelfSub()'s doc comment).
);

CREATE TABLE IF NOT EXISTS sub_offers (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  sub_request_id        INTEGER NOT NULL REFERENCES sub_requests(id) ON DELETE CASCADE,
  candidate_player_id   INTEGER REFERENCES players(id),
  broader_list_id       INTEGER REFERENCES broader_sub_list(id),
  token                 TEXT UNIQUE NOT NULL, -- SHA-256 hash of the raw token
  status                TEXT NOT NULL DEFAULT 'pending', -- pending | claimed | closed
  responded_at          TEXT,
  was_new_person        INTEGER NOT NULL DEFAULT 0 -- set only on the one offer arrangeSelfSub() creates for a genuinely-new person (selection.newPerson, matched against neither `players` nor `broader_sub_list` by email — see that function's "isNewPerson" branch and the resulting sub.self_arranged_new_person activity-log entry). Every other offer (the normal roster fan-out, an escalation to the broader list, or a self-arranged pick of someone already known) leaves this 0. Lets the Player Behavior stats (Kyle, 2026-09-15) bucket a filled sub_request's winning offer as "roster" / "broader sub list" / "unknown player" without guessing from timestamps.
);

-- Direct player-to-player swap proposals: a two-way trade between two
-- specific players' own upcoming slots (initiator gives up their own
-- assignment, takes over the target's), distinct from sub_requests/sub_offers
-- above (a one-to-many fan-out where someone drops out and anyone can claim
-- it). One row per proposal, single token since it's addressed to exactly
-- one specific player rather than fanned out. See swapFlow.js.
CREATE TABLE IF NOT EXISTS swap_requests (
  id                      INTEGER PRIMARY KEY AUTOINCREMENT,
  initiator_assignment_id INTEGER NOT NULL REFERENCES week_assignments(id) ON DELETE CASCADE,
  target_assignment_id    INTEGER NOT NULL REFERENCES week_assignments(id) ON DELETE CASCADE,
  initiator_player_id     INTEGER REFERENCES players(id), -- snapshot of who proposed it, taken at proposeSwap() time; see identity-drift check in respondToSwap()
  target_player_id        INTEGER NOT NULL REFERENCES players(id),
  token                   TEXT UNIQUE NOT NULL, -- SHA-256 hash of the raw token; raw value only ever exists in the emailed link
  nudge_token             TEXT UNIQUE, -- SHA-256 hash of a second, additionally-valid token minted for the one-time nudge email (see nudgeOverdueSwaps() in swapFlow.js) — does not invalidate `token`, same "multiple valid tokens" reasoning as week_assignment_tokens
  nudged_at               TEXT, -- set once the overdue nudge has gone out; NULL until then, so the cron pass never nudges twice
  status                  TEXT NOT NULL DEFAULT 'pending', -- pending | accepted | declined | cancelled | expired (expired = still pending once the earlier of the two involved weeks' match times arrived — see expireStaleSwaps())
  created_at              TEXT NOT NULL DEFAULT (datetime('now')),
  responded_at            TEXT
);
CREATE INDEX IF NOT EXISTS idx_swap_requests_initiator ON swap_requests(initiator_assignment_id);
CREATE INDEX IF NOT EXISTS idx_swap_requests_target ON swap_requests(target_assignment_id);

-- Bot-protection gate in front of proposeSwap(): /swap/start (an
-- unauthenticated public form — anyone can pick any two players from the
-- dropdown) used to call proposeSwap() directly, which immediately emails
-- the target player a real proposal and the initiator a confirmation. A
-- script could hit that endpoint over and over with no proof either named
-- player actually asked for anything. A row here is a not-yet-verified
-- proposal: /swap/start now only inserts one of these and emails the
-- *initiator* a "click to confirm it's really you" link — proposeSwap()
-- (and its two real emails) only fires once that link is clicked, same
-- "email yourself first" pattern as sub_request_verification in
-- subFlow.js/email.js. Single-use — the row is deleted the moment its
-- token is consumed (see swapFlow.js's consumeProposalVerification()).
CREATE TABLE IF NOT EXISTS swap_proposal_verifications (
  id                      INTEGER PRIMARY KEY AUTOINCREMENT,
  token                   TEXT UNIQUE NOT NULL, -- SHA-256 hash of the raw token; raw value only ever exists in the emailed link
  initiator_assignment_id INTEGER NOT NULL REFERENCES week_assignments(id) ON DELETE CASCADE,
  target_assignment_id    INTEGER NOT NULL REFERENCES week_assignments(id) ON DELETE CASCADE,
  created_at              TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS email_log (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  to_email        TEXT NOT NULL,
  subject         TEXT NOT NULL,
  category        TEXT NOT NULL, -- reminder | followup_reminder | sub_request | escalation | sub_filled | custom | confirmation | adhoc_invite | adhoc_reminder | adhoc_final | adhoc_not_enough | score_reminder (this list is not exhaustive — several categories added since have never been backfilled in here, e.g. admin_report/admin_report_manual, blackout_notice, sub_filled_original, the swap_* categories, test)
  status          TEXT NOT NULL DEFAULT 'sent', -- sent | failed | logged_dev_mode (no SMTP configured, console-only) | skipped_no_email (recipient has a @no-email.invalid placeholder address, e.g. a one-time sub added with no email on file — see email.js's NO_EMAIL_DOMAIN)
  sent_at         TEXT NOT NULL DEFAULT (datetime('now')),
  related_week_id INTEGER REFERENCES weeks(id),
  body_html       TEXT, -- the exact HTML body as sent (wrapped), so the Email Log page can show what a recipient actually saw. NULL for rows logged before this column existed (Kyle, 2026-09-27).
  thread_key      TEXT -- groups emails that belong to one event on the Email Log page, e.g. 'sub:<sub_requests.id>' for every email in one sub request's trail. 'pending-sub:<week_assignments.id>' marks a verification email sent before the sub request exists; it's re-tagged to 'sub:<id>' once the request is created. NULL = ungrouped (every email before 2026-09-27, and every non-sub email for now).
);

-- Audit trail of admin-triggered changes, added 2026-08-10 for accountability
-- now that multiple admins share full, untiered access (see "Admin accounts"
-- in CLAUDE.md — any admin can do anything, so knowing *who* made a given
-- change is otherwise unrecoverable). Deliberately a plain, human-readable
-- log (one row per action with a prose `description`), matching this app's
-- existing email_log pattern (simple, queryable, no structured diff system)
-- rather than a heavier audit framework for a small, low-volume admin panel.
CREATE TABLE IF NOT EXISTS admin_activity_log (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  admin_id      INTEGER REFERENCES admins(id), -- nullable defensively; admins are never hard-deleted today (only deactivated — see admin.js), but not relied on
  admin_name    TEXT NOT NULL, -- denormalized snapshot at the time of the action, so the log reads correctly with one query, no JOIN required
  action        TEXT NOT NULL, -- short machine-readable tag, e.g. 'session.schedule', 'week.reassign' — see activityLog.js for the full list
  description   TEXT NOT NULL, -- human-readable summary, e.g. "Reassigned Wed 9/9 slot from Kyle Krieg to Marcus Gable"
  session_id    INTEGER REFERENCES sessions(id), -- nullable (not every action is session-scoped, e.g. admin account management). Deliberately NOT cascaded on session delete, same reasoning as email_log.related_week_id — a change record should outlive a deleted session for support/history purposes. POST /admin/sessions/:id/delete nulls this out first, same pattern it already uses for email_log.related_week_id.
  created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_activity_log_session ON admin_activity_log(session_id);
CREATE INDEX IF NOT EXISTS idx_activity_log_created ON admin_activity_log(created_at);

-- Ad-hoc pickup-game sign-ups (session_type = 'adhoc' — see CLAUDE.md). One
-- row per (week, roster player), created up front when the T-56h invite goes
-- out so the invite list and the sign-up state live in the same place.
-- `signed_up_at` is NULL until the player clicks their "I'm in" link — the
-- timestamp IS the first-come-first-served order, so court assignment is
-- always `ORDER BY signed_up_at` chunked into groups of 4, computed live
-- (see adhocFlow.js's courtGroupsForWeek()) rather than stored anywhere.
-- Reuses the same hashed-token pattern as every other emailed link in this
-- app (see tokens.js) — only the SHA-256 hash is stored, the raw value only
-- ever exists in the outbound email.
CREATE TABLE IF NOT EXISTS adhoc_signups (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  week_id             INTEGER NOT NULL REFERENCES weeks(id) ON DELETE CASCADE,
  player_id           INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  token               TEXT UNIQUE NOT NULL,
  reminder_token      TEXT UNIQUE, -- a second, additionally-valid token minted only if/when the T-30h stragglers reminder fires (see adhocFlow.js's mintReminderToken()) — the original invite's raw token can't be reused since only its hash is ever stored, same "don't kill a link that's already out" reasoning as swap_requests.nudge_token. NULL until a reminder is actually sent.
  invited_at          TEXT NOT NULL DEFAULT (datetime('now')),
  signed_up_at        TEXT,   -- NULL = hasn't clicked "I'm in" yet
  reminded_at         TEXT,   -- set once the T-30h stragglers-only reminder has gone out to this player for this week
  result_notified_at  TEXT,   -- set once the T-24h final email (their court, or "not enough signed up") has gone out
  UNIQUE(week_id, player_id)
);
CREATE INDEX IF NOT EXISTS idx_adhoc_signups_week ON adhoc_signups(week_id);

-- One cached forecast per week (Kyle, 2026-09-05): "the weather forecast
-- should update hourly between the first email for that week goes out to 1
-- hour after the playing time." Refreshed by weather.js's refreshDueWeeks()
-- (called from cron.js's tick loop), which upserts this single row per
-- week_id rather than keeping history — the site widget and the
-- confirmation/"who's in" emails both just read whatever's cached here at
-- render/send time, they never call the OpenWeatherMap API themselves. Using
-- week_id as the PRIMARY KEY (not a separate id/UNIQUE pair) is deliberate:
-- there is only ever "the current forecast for this week," never more than
-- one live at a time, so a plain 1:1 keyed table is the honest shape rather
-- than an ever-growing log table nothing reads more than the latest row of.
-- raw_json keeps the full API response for the one specific 3-hour forecast
-- slot picked as closest to match time, in case a future feature wants more
-- than the handful of fields broken out into their own columns below.
CREATE TABLE IF NOT EXISTS week_weather (
  week_id         INTEGER PRIMARY KEY REFERENCES weeks(id) ON DELETE CASCADE,
  fetched_at      TEXT NOT NULL,   -- when this row was last (over)written — staleness check for the hourly refresh cadence
  forecast_time   TEXT,            -- the actual forecast timestamp (UTC) of the specific 3-hour slot chosen as closest to the match's own start time
  temp_f          REAL,
  feels_like_f    REAL,
  condition       TEXT,            -- e.g. "light rain" — OpenWeatherMap's own short description
  icon            TEXT,            -- OpenWeatherMap icon code, e.g. "10d" — see weather.js's weatherIconUrl()
  precip_chance   REAL,            -- 0.0-1.0 probability of precipitation ("pop" in OWM's response)
  wind_mph        REAL,
  raw_json        TEXT
);

CREATE INDEX IF NOT EXISTS idx_weeks_session ON weeks(session_id);
CREATE INDEX IF NOT EXISTS idx_assignments_week ON week_assignments(week_id);
CREATE INDEX IF NOT EXISTS idx_assignments_player ON week_assignments(player_id);
CREATE INDEX IF NOT EXISTS idx_blackout_session_player ON blackout_dates(session_id, player_id);
CREATE INDEX IF NOT EXISTS idx_player_constraints_session ON player_constraints(session_id);
CREATE INDEX IF NOT EXISTS idx_assignment_tokens_assignment ON week_assignment_tokens(week_assignment_id);

-- ---------------------------------------------------------------------------
-- Seasons and the three-tier stats model (Kyle, 2026-09-25).
--
-- Three boards, each computed live from the raw scores (week_assignments.
-- games_won + week_court_games.games_played) — nothing here ever stores or
-- deletes a score:
--   * Session board  — everything scored in one session.
--   * Season board   — every session in one season that has "count toward
--                      season" on, minus excluded players.
--   * Master board   — every session with stats on, every season, every
--                      player, from the most recent master reset date on.
-- A session with games_won_enabled = 0 ("Stats off") feeds none of these.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS seasons (
  id                        INTEGER PRIMARY KEY AUTOINCREMENT,
  name                      TEXT NOT NULL,            -- admin-named, e.g. "Indoor Frontenac 2026"
  stats_visible             INTEGER NOT NULL DEFAULT 1, -- 0 hides this season's board and graphs from the public stats page (admin always sees it)
  min_matches_for_win_pct   INTEGER NOT NULL DEFAULT 2, -- season board's own "still building a sample" cutoff
  archived_at               TEXT,                      -- set when the whole season is archived (its sessions get the same timestamp — see admin.js's season archive route)
  created_at                TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Players hidden from ONE session's board. A player excluded from a session
-- also has THAT session's scores left out of the season board, but their
-- other sessions in the same season still count. Never affects the master.
CREATE TABLE IF NOT EXISTS session_stat_exclusions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id  INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  player_id   INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  UNIQUE(session_id, player_id)
);

-- Players hidden from a season's board entirely (every session in it).
CREATE TABLE IF NOT EXISTS season_stat_exclusions (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  season_id   INTEGER NOT NULL REFERENCES seasons(id) ON DELETE CASCADE,
  player_id   INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  UNIQUE(season_id, player_id)
);

-- Master leaderboard resets. A reset never deletes scores: it records the
-- date the master starts counting from (weeks with match_date >= reset_date)
-- and freezes a JSON snapshot of the board as it stood so the old standings
-- stay viewable. `undone_at` set = the reset was rolled back and no longer
-- counts as the baseline.
CREATE TABLE IF NOT EXISTS master_stat_resets (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  reset_date     TEXT NOT NULL,   -- ISO date the new master period starts
  label          TEXT NOT NULL,   -- e.g. "Master board before reset on 2027-05-01"
  snapshot_json  TEXT NOT NULL,   -- { totals: [...], winPct: [...], since: <previous baseline date or null> }
  created_by     TEXT,
  created_at     TEXT NOT NULL DEFAULT (datetime('now')),
  undone_at      TEXT
);

-- Player-entered "other tennis" (Kyle, 2026-09-26): matches a player is
-- playing OUTSIDE any session in this app (another league, a club match,
-- a pickup game elsewhere). Purely a calendar convenience — folded into the
-- player's .ics download and subscribe feed so all their tennis lives in one
-- calendar. Deliberately NOT tied to blackout dates or scheduling in any way.
CREATE TABLE IF NOT EXISTS personal_events (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  player_id         INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  event_date        TEXT NOT NULL,              -- 'YYYY-MM-DD'
  start_time        TEXT NOT NULL,              -- 'HH:MM' 24h, same naive wall-clock convention as sessions.match_time
  duration_minutes  INTEGER NOT NULL DEFAULT 90,
  club              TEXT,                       -- free text, optional
  court             TEXT,                       -- free text, optional
  notes             TEXT,                       -- free text, optional
  created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_personal_events_player ON personal_events(player_id, event_date);

-- Emailed "edit my other tennis" links. My Page has no login, so adding or
-- deleting entries needs proof the browser belongs to that player: a link
-- emailed to their own address. Reusable (not single-use) until expires_at,
-- so a player can bookmark it; only the SHA-256 hash is stored, same as every
-- other token in this app (tokens.js).
CREATE TABLE IF NOT EXISTS personal_event_tokens (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  player_id   INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
  token_hash  TEXT NOT NULL UNIQUE,
  expires_at  TEXT NOT NULL,                    -- ISO timestamp (UTC)
  created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Suspended automated actions (Kyle, 2026-09-27): a per-line "Suspend"
-- checkbox on the admin Status page's "Upcoming automated actions" table.
-- One row per (week, action type) — action_type is one of 'reminder',
-- 'followup', 'escalation' (the three email-sending cron passes; week
-- locking is bookkeeping with no manual equivalent, so it isn't suspendable).
-- While a row exists, the matching cron pass skips that week. The first
-- tick at/after the action's due time writes a "Suspended — did not fire"
-- entry to admin_activity_log and stamps skipped_at; from then on the
-- action is COMPLETE (never fires later, can't be un-suspended) — finishing
-- the job is up to an admin by some manual route (Send reminders now,
-- Resend link, Reassign, etc.). Unchecking before the due time deletes the
-- row, which puts the action back on its normal schedule.
CREATE TABLE IF NOT EXISTS suspended_actions (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  week_id             INTEGER NOT NULL REFERENCES weeks(id) ON DELETE CASCADE,
  action_type         TEXT NOT NULL CHECK (action_type IN ('reminder', 'followup', 'escalation')),
  suspended_by_id     INTEGER, -- admins.id; deliberately no FK (name is snapshotted below, same as admin_activity_log)
  suspended_by_name   TEXT NOT NULL,
  suspended_at        TEXT NOT NULL DEFAULT (datetime('now')),
  skipped_at          TEXT, -- set when the due time passed while suspended ("did not fire" logged); NULL = still pending
  UNIQUE (week_id, action_type)
);

-- News posts / announcement banner (Kyle, 2026-09-28): a multipurpose blog
-- (new-feature write-ups with screenshots, an end-of-season happy hour, etc.)
-- shown at /news, plus an optional banner on every player-facing page that
-- links to one post. body is a tiny Markdown-ish syntax rendered (escaped)
-- by src/services/news.js. show_banner + banner_until control the banner;
-- when several posts qualify, the pinned/newest one wins. published_at is
-- stamped the first time a post is published and kept through later edits.
CREATE TABLE IF NOT EXISTS announcements (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  title         TEXT NOT NULL,
  body          TEXT NOT NULL DEFAULT '',
  published     INTEGER NOT NULL DEFAULT 0,
  pinned        INTEGER NOT NULL DEFAULT 0,
  show_banner   INTEGER NOT NULL DEFAULT 0,
  banner_text   TEXT,                            -- short banner line; blank = use the title
  banner_style  TEXT NOT NULL DEFAULT 'info',    -- 'info' | 'celebrate' | 'alert'
  banner_until  TEXT,                            -- 'YYYY-MM-DD' (site timezone), inclusive; NULL = no end
  author_name   TEXT,
  published_at  TEXT,
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- Screenshots/photos for news posts, stored in the DB (not on disk) so the
-- existing VACUUM INTO backups include them automatically. Served at
-- /news/img/:id. announcement_id is NULL between upload and the post's first
-- save; deleting a post removes the images only it referenced.
CREATE TABLE IF NOT EXISTS announcement_images (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  announcement_id  INTEGER REFERENCES announcements(id) ON DELETE SET NULL,
  mime             TEXT NOT NULL,
  bytes            INTEGER NOT NULL,
  original_name    TEXT,
  data             BLOB NOT NULL,
  created_at       TEXT NOT NULL DEFAULT (datetime('now'))
);
